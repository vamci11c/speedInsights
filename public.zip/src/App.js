import { useState } from "react";
import "./App.css";

function App() {
  const [urlAdded, setUrlAdded] = useState("");
  const getPageSpeedInsights = async () => {
    const url = document.getElementById("urlInput").value.trim();
    console.log("url", url);
    const apiKey = "AIzaSyCHhvIvFoyATIwow71aP3qRde_b1LWtY54"; // Replace with your actual PageSpeed Insights API key
    if (!url) {
      alert("Please enter a valid URL.");
      return;
    }
    try {
      const apiUrl = `https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=${url}&key=${apiKey}&strategy=mobile`;
      const response = await fetch(apiUrl);
      console.log("response", response);
      const data = await response.json();
      console.log("data", data);
    } catch (error) {
      console.error("Error fetching PageSpeed Insights:", error);
      alert("Error fetching PageSpeed Insights. Please try again later.");
    }
  };

  return (
    <div className="App">
      <div class="container">
        <h2>Page Speed Insights</h2>
        <label for="urlInput">Enter URL:</label>
        <input type="text" id="urlInput" placeholder="Enter your website URL" />

        <button onClick={() => getPageSpeedInsights()}>Get Insights</button>

        <div id="result">
          <h3>Performance Metrics:</h3>
          <p>
            <strong>First Contentful Paint:</strong>{" "}
            <span id="firstContentfulPaint"></span>
          </p>
          <p>
            <strong>Largest Contentful Paint:</strong>{" "}
            <span id="largestContentfulPaint"></span>
          </p>
          <p>
            <strong>Cumulative Layout Shift:</strong>{" "}
            <span id="cumulativeLayoutShift"></span>
          </p>
          <p>
            <strong>Total Blocking Time:</strong>{" "}
            <span id="totalBlockingTime"></span>
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;
